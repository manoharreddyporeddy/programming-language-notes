
1. installation:

  npm install
        # sudo npx create-react-app my-app
        # sudo chmod 777 -R my-app
        # cd my-app
        # sudo npm install react-xml-parser


2. 
below files are input & output sample file
    __sample_html
    __sample_json

3.
App.js
  has the code
  imports the 